<template>
  <h1>Hello, World!</h1>
</template>

<script lang="ts">
import { defineComponent } from 'vue';

export default defineComponent({
  name: 'HelloWorld',
});
</script>

<style scoped>
h1 {
  color: #42b983;
}
</style>